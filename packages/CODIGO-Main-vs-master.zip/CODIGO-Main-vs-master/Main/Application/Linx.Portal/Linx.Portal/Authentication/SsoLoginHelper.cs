﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;
using Microsoft.Identity.Client;

namespace Linx.Portal.Authentication
{
    /// <summary>
    /// OmniPOS-style orchestration: MSAL ForceLogin → session NomeAutenticacao (CONTINUAR) → local user session.
    /// Azure token is identity proof only; Portal Forms cookie uses the Linx login typed before SSO.
    /// login_hint on the authorize URL is EMAIL (UPN), not NomeAutenticacao.
    /// </summary>
    public static class SsoLoginHelper
    {
        public const string ContingencySessionKey = "EnableContingencySSO";
        public const string OAuthStateSessionKey = "SsoOAuthState";
        public const string PendingLocalUserSessionKey = "PortalSsoPendingNomeAutenticacao";
        public const string LoginHintEmailSessionKey = "PortalSsoLoginHintEmail";

        public static string ExtractLocalLogin(string upn)
        {
            if (string.IsNullOrWhiteSpace(upn))
                return null;

            var at = upn.IndexOf('@');
            var local = (at > 0 ? upn.Substring(0, at) : upn).ToLowerInvariant();
            return local;
        }

        /// <summary>
        /// After Azure succeeds, continue as the Linx login typed on CONTINUAR (session).
        /// Falls back to the Azure UPN prefix only when no session login was stored.
        /// </summary>
        public static string ResolveLocalLoginAfterSso(HttpSessionStateBase session, string azureUpn)
        {
            if (session != null)
            {
                string pending = session[PendingLocalUserSessionKey] as string;
                if (!string.IsNullOrWhiteSpace(pending))
                    return pending.Trim();
            }

            return ExtractLocalLogin(azureUpn);
        }

        public static void RememberPendingLocalUser(HttpSessionStateBase session, string nomeAutenticacao)
        {
            if (session == null || string.IsNullOrWhiteSpace(nomeAutenticacao))
                return;
            session[PendingLocalUserSessionKey] = nomeAutenticacao.Trim();
        }

        public static void RememberLoginHintEmail(HttpSessionStateBase session, string email)
        {
            if (session == null)
                return;
            if (string.IsNullOrWhiteSpace(email))
            {
                session.Remove(LoginHintEmailSessionKey);
                return;
            }
            session[LoginHintEmailSessionKey] = email.Trim();
        }

        public static string ResolveAzureLoginHint(string email, string nomeAutenticacao)
        {
            if (LooksLikeEmail(email))
                return email.Trim();
            if (LooksLikeEmail(nomeAutenticacao))
                return nomeAutenticacao.Trim();
            return null;
        }

        public static bool LooksLikeEmail(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;
            int at = value.IndexOf('@');
            return at > 0 && at < value.Length - 1;
        }

        public static void ClearPendingLocalUser(HttpSessionStateBase session)
        {
            if (session == null)
                return;
            session.Remove(PendingLocalUserSessionKey);
            session.Remove(LoginHintEmailSessionKey);
        }

        /// <summary>
        /// Drop SSO session keys so the next attempt starts from the identifier-first page.
        /// </summary>
        public static void ClearSsoState(HttpSessionStateBase session)
        {
            ClearContingency(session);
            ClearPendingLocalUser(session);
            if (session != null)
                session.Remove(OAuthStateSessionKey);
        }

        /// <summary>
        /// Expire Portal SSO/MSAL/Forms cookies and the local MSAL cache file.
        /// Azure AD cookies live on login.microsoftonline.com and cannot be cleared here;
        /// BeginForceLoginAsync already uses prompt=login for a fresh credential prompt.
        /// </summary>
        public static void ClearSsoBrowserCookies(HttpRequestBase request, HttpResponseBase response)
        {
            if (response == null)
                return;

            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (request != null && request.Cookies != null)
            {
                foreach (string name in request.Cookies.AllKeys)
                {
                    if (IsSsoRelatedCookie(name))
                        names.Add(name);
                }
            }

            try
            {
                if (!string.IsNullOrEmpty(FormsAuthentication.FormsCookieName))
                    names.Add(FormsAuthentication.FormsCookieName);
            }
            catch
            {
            }

            names.Add(".ASPXAUTH");
            names.Add("FedAuth");

            foreach (string name in names)
                ExpireCookie(response, name);

            try
            {
                new FileTokenCacheStore("msal.cache", "LinxPortal").Clear();
            }
            catch
            {
            }
        }

        private static bool IsSsoRelatedCookie(string name)
        {
            if (string.IsNullOrEmpty(name))
                return false;
            string n = name.ToLowerInvariant();
            return n.IndexOf("sso", StringComparison.Ordinal) >= 0
                || n.IndexOf("msal", StringComparison.Ordinal) >= 0
                || n.IndexOf("azure", StringComparison.Ordinal) >= 0
                || n.IndexOf("openid", StringComparison.Ordinal) >= 0
                || n.IndexOf("oidc", StringComparison.Ordinal) >= 0
                || n.IndexOf("nonce", StringComparison.Ordinal) >= 0
                || n.IndexOf("fedauth", StringComparison.Ordinal) >= 0
                || string.Equals(n, ".aspxauth", StringComparison.OrdinalIgnoreCase);
        }

        private static void ExpireCookie(HttpResponseBase response, string name)
        {
            if (response == null || string.IsNullOrEmpty(name))
                return;
            var expired = new HttpCookie(name)
            {
                Expires = DateTime.UtcNow.AddDays(-1),
                Value = string.Empty,
                HttpOnly = true,
                Path = "/"
            };
            response.Cookies.Set(expired);
        }

        public static MsalAuthenticationService CreateService()
        {
            var options = Utils.GetAzureAdOptions();
            return new MsalAuthenticationService(options, new FileTokenCacheStore("msal.cache", "LinxPortal"));
        }

        public static async Task<Uri> BeginForceLoginAsync(HttpSessionStateBase session, string nomeAutenticacao = null, string loginHintEmail = null)
        {
            var state = Guid.NewGuid().ToString("N");
            if (session != null)
                session[OAuthStateSessionKey] = state;
            RememberPendingLocalUser(session, nomeAutenticacao);
            RememberLoginHintEmail(session, loginHintEmail);

            string azureHint = ResolveAzureLoginHint(loginHintEmail, nomeAutenticacao);
            var service = CreateService();
            return await service.GetAuthorizationUrlAsync(state, forceLogin: true, loginHint: azureHint).ConfigureAwait(false);
        }

        public static async Task<AuthenticationResultModel> CompleteForceLoginAsync(
            string code,
            string state,
            HttpSessionStateBase session)
        {
            if (session != null)
            {
                var expected = session[OAuthStateSessionKey] as string;
                session.Remove(OAuthStateSessionKey);
                if (!string.IsNullOrEmpty(expected) &&
                    !string.Equals(expected, state, StringComparison.Ordinal))
                {
                    return new AuthenticationResultModel
                    {
                        IsAuthenticated = false,
                        Message = "Estado de autenticação inválido. Tente novamente."
                    };
                }
            }

            var service = CreateService();
            return await service.CompleteAuthorizationCodeAsync(code).ConfigureAwait(false);
        }

        public static string MapMsalException(Exception ex, out bool suggestContingency)
        {
            suggestContingency = false;
            if (ex == null)
                return "Não foi possível realizar autenticação.";

            for (Exception walk = ex; walk != null; walk = walk.InnerException)
            {
                var canceled = walk as MsalClientException;
                if (canceled != null &&
                    string.Equals(canceled.ErrorCode, "authentication_canceled", StringComparison.OrdinalIgnoreCase))
                    return "O usuário abortou o processo de autenticação.";

                var uiFailed = walk as MsalClientException;
                if (uiFailed != null &&
                    string.Equals(uiFailed.ErrorCode, "authentication_ui_failed", StringComparison.OrdinalIgnoreCase))
                    suggestContingency = true;

                if (walk is MsalServiceException)
                    suggestContingency = true;
            }

            string detail = FormatExceptionChain(ex);
            string hint = DescribeSsoConfig();
            if (!string.IsNullOrEmpty(hint))
                return hint + " | " + detail;
            return detail;
        }

        public static string DescribeSsoConfig()
        {
            try
            {
                AzureAdOptions options = Utils.GetAzureAdOptions();
                StringBuilder sb = new StringBuilder();
                sb.Append("SSO_CLIENT_ID=").Append(string.IsNullOrWhiteSpace(options.ClientId) ? "vazio" : "ok");
                sb.Append(" SSO_TENANT_ID=").Append(string.IsNullOrWhiteSpace(options.TenantId) ? "vazio" : "ok");
                sb.Append(" SSO_REDIRECT_URI=").Append(string.IsNullOrWhiteSpace(options.RedirectUri) ? "vazio" : options.RedirectUri);
                if (string.IsNullOrWhiteSpace(options.ClientSecret))
                    sb.Append(" SSO_CLIENT_SECRET=vazio no PortalSettings");
                else
                    sb.Append(" SSO_CLIENT_SECRET=ok(len=").Append(options.ClientSecret.Length).Append(")");
                return sb.ToString();
            }
            catch (Exception cfgEx)
            {
                return "PortalSettings: " + cfgEx.Message;
            }
        }

        private static string FormatExceptionChain(Exception ex)
        {
            var parts = new List<string>();
            for (Exception e = ex; e != null && parts.Count < 4; e = e.InnerException)
            {
                var svc = e as MsalServiceException;
                var cli = e as MsalClientException;
                string piece;
                if (svc != null)
                    piece = string.IsNullOrEmpty(svc.ErrorCode) ? svc.Message : (svc.ErrorCode + ": " + svc.Message);
                else if (cli != null)
                    piece = string.IsNullOrEmpty(cli.ErrorCode) ? cli.Message : (cli.ErrorCode + ": " + cli.Message);
                else
                    piece = e.GetType().Name + ": " + e.Message;
                piece = RedactSecrets(piece);
                if (!string.IsNullOrWhiteSpace(piece) && !parts.Contains(piece))
                    parts.Add(piece);
            }
            if (parts.Count == 0)
                return "Não foi possível realizar autenticação.";
            return string.Join(" | ", parts.ToArray());
        }

        private static string RedactSecrets(string text)
        {
            if (string.IsNullOrEmpty(text))
                return text;
            try
            {
                AzureAdOptions options = Utils.GetAzureAdOptions();
                if (!string.IsNullOrWhiteSpace(options.ClientSecret) && text.IndexOf(options.ClientSecret, StringComparison.Ordinal) >= 0)
                    text = text.Replace(options.ClientSecret, "***");
            }
            catch
            {
            }
            return text;
        }

        public static bool IsContingencyEnabled(HttpSessionStateBase session)
        {
            if (session == null)
                return false;
            var value = session[ContingencySessionKey];
            return value != null && Convert.ToBoolean(value);
        }

        public static void EnableContingency(HttpSessionStateBase session)
        {
            if (session != null)
                session[ContingencySessionKey] = true;
        }

        public static void ClearContingency(HttpSessionStateBase session)
        {
            if (session != null)
                session.Remove(ContingencySessionKey);
        }
    }
}
