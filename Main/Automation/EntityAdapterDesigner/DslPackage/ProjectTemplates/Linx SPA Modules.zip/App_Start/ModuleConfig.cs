using System;
using System.Web.Optimization;

namespace $safeprojectname$
{
    public class ModuleConfig
    {        
    }
}




